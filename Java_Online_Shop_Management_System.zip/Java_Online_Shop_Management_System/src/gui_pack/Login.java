package gui_pack;

public class Login {
	
	String unane;
	String psass;
	
	public Login(String un, String pa) {
		
	}

}
