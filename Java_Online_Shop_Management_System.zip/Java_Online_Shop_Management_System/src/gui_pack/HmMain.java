package gui_pack;

//import javax.swing.JFrame;
//import java.util.*;

public class HmMain {

	public static void main(String args[]) {
		Homepage H = new Homepage();

		// H.addComponentsToFrame();
		// H.testAnnonymousClass();
		H.setVisible(true);
		// H.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}